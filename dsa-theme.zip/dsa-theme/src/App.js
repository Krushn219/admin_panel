// ** Router Import
import Router from './router/Router'

const App = () => <Router />

export default App
